"""
runme_Augsburg.py
Calculate heat demand for Augsburg 
lodersky @ TUM ENS
05.2019
"""

import multiprocessing

import UrbanHeatPro.Functions as UrbanHeatPro
import UrbanHeatPro.Classes as UrbanHeatPro



# INPUT DATA
# ----------------------------------------------------------------------------------------------------
# 1. SIMULATION
#	 1.1 General
#		 region 	<str>	name of statistical region/city/urban area
#	 	 N 			<int>	number of simulation runs.
#							One run calculates the heat demand for the whole region.
#							SynCity remains the same.
#	 	 resolution <int> 	temporal resolution [min]
#	 	 offset 	<int> 	initial time step
#	 	 length 	<int> 	number of time steps to simulate
#		 timesteps	<int>	vector of time steps to simulate
#		 number_of_typ_days <int> number of typical days to simulate
# 	 1.2 Scenarios
#		 sce_refurbishment	<str> Name of refurbishment scenario or None
#		 filename_Tamb		<str> Name of ambient temperature scenario or None
#	 1.3 Multiprocessing
#		 processes 	<int> 	number of processes to use for multiprocessing (parallelization)
#		 chunk_size <int>	number of buildings in chunk to save
#
region				= 'Augsburg'
N 	 	   			= 1
resolution 			= 60
(offset, length) 	= (0, 24*365)
timesteps 			= range(offset, offset + length)
number_of_typ_days  = 365
#
sce_refurbishment   = None
sce_Tamb		    = None
#
processes			= 16
chunk_size			= 1000

	#256
###
SIMULATION			= [[region], 
					   [N, resolution, timesteps, number_of_typ_days],
					   [sce_refurbishment, sce_Tamb], 
					   [processes, chunk_size]]


# 2. CITY
#	 2.1 Raw building data
#		 filename_buildings	<str>		name of csv file with raw building data or None.
#	 2.3 Synthetic city
#	 	 filename_syn_city 	<str>		name of csv file with synthetic city or None.
#	 2.2 Connection factor
#		 connection_factor 	<float>		share of buildings connected to the network (as decimal)
#	 2.3 City heat demand
#		 _space_heating 	<boolean>	specifies if space heating demand is calculated.
#								   		If False, heat losses and gains are also False.
#		 _hot_water 		<boolean>	specifies if hot water demand is calculated.
#		 _energy_only 		<boolean>	specifies if the focus is only on the aggregated heating energy 
# 								 		demand and not on the time series. If True, the hot water demand is 
#								 		calculated/added per day and not per time step.
#	 2.4 Base load
#		 base_load 			<float>		minimum load at every time step in W.
#
#filename_buildings  = None
filename_buildings  = 'example_buildings.csv'
#
filename_syn_city	= None

#
connection_factor	= 1.
#
_space_heating 		= True
_hot_water			= True
_energy_only		= False
#
base_load			= 0.
###
CITY				= [[filename_buildings, filename_syn_city], [connection_factor],
					   [_space_heating, _hot_water, _energy_only], [base_load]]

# 3. SPACE HEATING DEMAND
#	 3.1 Flags
#		 _internal_gains 		<boolean>	specifies if internal gains are calculated.
#		 _solar_gains 			<boolean>	specifies if solar losses are calculated.
#		 _active_population 	<boolean>	specifies if statistics for active population are used to create
#									   		synthetic population profiles (occupancy)
#		 _workday_weekend		<boolean>   specifies if workdays and weekends are differentiated.
#							  				Use only when full year is simulated.
#		 _monthly_sh_prob		<boolean>	specifies if monthly probability of using heating is used
#    3.2 Temperature
# 		 Tb0_str 				<str>		Building initial temperature as string 'Tset' or 'Tamb'.
#		 dTset 					<float>		Temperature difference to modify Tset_min, Tset_max in degC
#	 3.3 Heating system
#		 eta 					<float>		heating system efficiency
#		 thermal_intertia 		<float>		weight of the delivered power from previous time step.
#								   			i.e. how much can the output power change with respect to the previous time step?
#	     dT_per_hour 			<float>		maximum temperature difference allowed in the building in degC / h.
#	 3.4 Demand Side Management
#		 _night_set_back 		<float>		share of buildings with night set-back
#		 schedule_nsb 			<list>		[start, end] of night set-back in hours
#		 T_nsb 					<float>		night set-back temperature in degC
# 		 power_reduction 		<float>		reduced power as decimal. Input power = 1 - power_reduction
_internal_gains		= True
_solar_gains		= True	
_active_population  = True
_workday_weekend	= True
_monthly_sh_prob	= True
#
Tb0_str				= 'Tset'
dTset				= 0.			
#
eta					= 1.0
dT_per_hour			= 0.1	
thermal_inertia		= 0.5
#
_night_set_back		= 0.5
schedule_nsb	    = [23, 6]	
T_nsb				= 19
power_reduction		= 0
#
###
SPACE_HEATING		= [[_internal_gains, _solar_gains, _active_population, _workday_weekend, _monthly_sh_prob],
					   [None],
					   [Tb0_str, dTset],
					   [eta, dT_per_hour, thermal_inertia],
					   [_night_set_back, schedule_nsb, T_nsb, power_reduction]]

					   
# 4. HOT WATER DEMAND
#	 4.1 Hot water temperature
#		 Tw 			<float> Hot water temperature in degC
#    4.2 Hot water tank
# 		 hw_tank_limit 	<float> Lower limit of hot water tank as decimal.
#									Below this limit, hw tank is refilled.
#		 hw_flow 		<float> Volume flow to refill hot water tank in L/min
Tw				    = 60
#
hw_tank_limit		= 0.1
hw_flow				= 15
###
HOT_WATER			= [[Tw], [hw_tank_limit, hw_flow]]


# 5. REPORTING
# 	0 No results saved or plotted
#	1 Results per simulation
#   2 Results per building
plot 				= 0
save 				= 2
debug 				= 2
###
REPORTING			= [plot, save, debug]


# MAIN
# --------------------------------------------------------------------------------
if __name__ == '__main__':

	M = 1 # Number of runs  --> N = number of runs with same syncity / M = runs with different syscity
			  
	bezirk = 'Augsburg'
	filename_buildings = 'example_buildings.csv'
	
	for m in range(M):
	
		print('\n\n//////////////////////////////////////')
		print('Augsburg-{}'.format(m))
		print('//////////////////////////////////////\n')

		# Simulation name
		NAME 	  = 'Augsburg-{}'.format(m)
		
		# Variables
		## region
		SIMULATION[0][0] = bezirk
		## filename_buildings
		CITY[0][0] = filename_buildings




		multiprocessing.freeze_support()
		#    If the freeze_support() line is omitted then trying to run the frozen executable will raise RuntimeError.
    	#		Calling freeze_support() has no effect when invoked on any operating system other than Windows. In addition, if the module is being run normally by the Python interpreter on Windows (the program has not been frozen), then freeze_support() has no effect.

		my_Simulation = UrbanHeatPro.Simulation(NAME, SIMULATION, CITY, SPACE_HEATING, HOT_WATER, REPORTING)
		my_Simulation.run(include_date = False)
